package com.bh183.hendrawan;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Queue;

public class DatabaseHandler extends SQLiteOpenHelper {

    private final static int DATABASE_VERSION = 2;
    private final static String DATABASE_NAME = "db_buku";
    private final static String TABLE_BUKU ="t_buku";
    private final static String KEY_ID_BUKU= "ID_Buku";
    private final static String KEY_JUDUL = "Judul";
    private final static String KEY_TGL = "Tanggal";
    private final static String KEY_GAMBAR = "Gambar";
    private final static String KEY_TERBIT ="Terbit";
    private final static String KEY_PENERBIT = "Penerbit";
    private final static String KEY_PENULIS = "Penulis";
    private final static String KEY_ISI_BUKU = "Isi_Buku";
    private final static String KEY_LINK = "Link";
    private SimpleDateFormat sdFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm", Locale.getDefault());
    private Context context;


    public DatabaseHandler(Context ctx){
        super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = ctx;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_BUKU = " CREATE TABLE " + TABLE_BUKU
                + " ( " + KEY_ID_BUKU + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_JUDUL + " TEXT, " + KEY_TGL + " DATE, "
                + KEY_GAMBAR + " TEXT, " + KEY_TERBIT + " TEXT, "
                + KEY_PENERBIT + " TEXT, " + KEY_PENULIS + " TEXT, "
                + KEY_ISI_BUKU + " TEXT, " + KEY_LINK + " TEXT);";

        db.execSQL(CREATE_TABLE_BUKU);
        inisialisasiBukuAwal(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_BUKU;
        db.execSQL(DROP_TABLE);
        onCreate(db);
    }

    public void tambahBuku(Buku dataBuku){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBuku.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBuku.getTanggal()));
        cv.put(KEY_GAMBAR, dataBuku.getGambar());
        cv.put(KEY_TERBIT, dataBuku.getTerbit());
        cv.put(KEY_PENERBIT, dataBuku.getPenerbit());
        cv.put(KEY_PENULIS, dataBuku.getPenulis());
        cv.put(KEY_ISI_BUKU, dataBuku.getIsiBuku());
        cv.put(KEY_LINK, dataBuku.getLink());

        db.insert(TABLE_BUKU, null, cv);
        db.close();
    }

    public void tambahBuku(Buku dataBuku, SQLiteDatabase db){
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBuku.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBuku.getTanggal()));
        cv.put(KEY_GAMBAR, dataBuku.getGambar());
        cv.put(KEY_TERBIT, dataBuku.getTerbit());
        cv.put(KEY_PENERBIT, dataBuku.getPenerbit());
        cv.put(KEY_PENULIS, dataBuku.getPenulis());
        cv.put(KEY_ISI_BUKU, dataBuku.getIsiBuku());
        cv.put(KEY_LINK, dataBuku.getLink());
        db.insert(TABLE_BUKU, null, cv);
    }

    public void editBuku(Buku dataBuku){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBuku.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBuku.getTanggal()));
        cv.put(KEY_GAMBAR, dataBuku.getGambar());
        cv.put(KEY_TERBIT, dataBuku.getTerbit());
        cv.put(KEY_PENERBIT, dataBuku.getPenerbit());
        cv.put(KEY_PENULIS, dataBuku.getPenulis());
        cv.put(KEY_ISI_BUKU, dataBuku.getIsiBuku());
        cv.put(KEY_LINK, dataBuku.getLink());

        db.update(TABLE_BUKU, cv, KEY_ID_BUKU + "=?", new String[]{String.valueOf(dataBuku.getIdBuku())});
        db.close();
    }

    public void hapusBuku (int idBuku){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_BUKU, KEY_ID_BUKU + "=?", new String[]{String.valueOf(idBuku)});
        db.close();
    }

    public ArrayList<Buku> getAllBuku(){
        ArrayList<Buku> dataBuku = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_BUKU;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor csr = db.rawQuery(query, null);
        if(csr.moveToFirst()){
            do {
                Date tempDate = new Date();
                try {
                    tempDate = sdFormat.parse(csr.getString(2));
                } catch (ParseException er) {
                    er.printStackTrace();
                }

                Buku tempBuku = new Buku(
                        csr.getInt(0),
                        csr.getString(1),
                        tempDate,
                        csr.getString(3),
                        csr.getString(4),
                        csr.getString(5),
                        csr.getString(6),
                        csr.getString(7),
                        csr.getString(8)
                );

                dataBuku.add(tempBuku);
            } while (csr.moveToNext());
        }

        return dataBuku;
    }

    private String storeImageFile(int id) {
        String location;
        Bitmap image = BitmapFactory.decodeResource(context.getResources(), id);
        location = inputActivity.saveImageToInternalStorage(image, context);
        return location;
    }

    private void inisialisasiBukuAwal(SQLiteDatabase db){
        int idBuku = 0;
        Date tempDate = new Date();

        try {
            tempDate = sdFormat.parse("");
        } catch (ParseException er){
            er.printStackTrace();
        }



        Buku buku1 = new Buku(
                idBuku,
                "PROMOSE ",
                tempDate,
                storeImageFile(R.drawable.buku1),
                "2016",
                "Loveable, Jakarta",
                "Dwitasari",
                "Rahman yang merupakan anak dari pemilik pesantren yang cukup terkenak di Jogja.Ia sebenarnya ingin di sekolahkan di Pesantren, tapi ia menolak.Rahman mempunyai teman yang bernama Aji.Mereka sudah bersahabat sudah lumayan lama.Karena itu mereka sangat dekat.Rahman mempunyai karakter yang lugu dan sederhana.Sedangkan sahabatnya Aji memiliki sifat yang sangat jauh dari Rahman.Aji mempunyai karakter yang playboy,dan suka gonta ganti pacar.Aji ingin sekali mengubah sahabatnya itu, ia ingin Rahman merasakan keindahan rasa cinta itu.Dan Aji menginginkan bahwa Rahman punya pacar ,seperti dirinya.Tapi secara halus Rahman menolak itu.Pada suatu hari, sepulang dari sekolah Aji dan Rahman sedang berbincang bincang.\n" +
                        "\n" +
                        "         Lagi lagi kali ini Aji mencoba membujuk Rahman,agar merubah dirinya yang terlalu ndeso atau kampungan.Sampai mereka berjalan ke lingkungan pesantren.Sepanjang perjalanan menuju rumah Rahman,Aji selalu melirik para santriwati yang sedang berjalan. Tapi para santriwati tidak sama sekali meliriknya.Malah  memperhatikan Rahman,termasuk salah satu santriwati yang paling cantik di pesantren itu yang bernama Salsabilla.Rahman masuk ke dalam rumahnya untuk pamit ke kedua orang tuanya untuk pergi mengantarkan Aji pulang.Ketika sampai di luar Rah,man tidak melihat Aji.\n" +
                        "\n" +
                        "          Ia malah melihat bayangan putih di bawah pohon beringin .Rahman benar benar kaget.Dan ternyata itu adalah Salsabilla.Salsabilla bilang kalau Rahman mengirim surat padanya dan mengajak ketemuan,makanya  ia datang kemari.Dalam hati Rahman menyumpahi Aji karena ini semua pastilah kerjaan Aji.Ternyata Bapak dari Rahman memperhatikan Rahman dari teras rumahnya .Dan tiba tiba Aji muncul.Lalu  Rahman mengantarkan Aji pulang ke rumahnya mengunakan sepeda .Sampai di rumah Ajji,Aji memberikan sebbuah kaset.Kaset itu berisi video porno.Aji menyarankan kepada Rahman untuk menonton kaset itu.Sampai di kamar rasa penasaran mendera Rahman.Imannya sudah tidak tahan lagi.Ketika menghidupkan kasetnay ternyata lampu mati.Keesikan harinay bapak Rahman sangat marah ,ia tidak menyangka kalau anakanya bisa sedemikian gila.Karena tidak hati hati,Rahman menyimpan kaset yang di berikan Aji, maka bapaknay mengetahui itu.Dan berencana untuk menikahkan Rahman.Semenjak kejadian itu ,Aji tidak pernah Nampak lagi batang hidungnya.Delapan belas bulan kemudian.Rahman sekarang sudah ada di Milan.Ia kuliah di salah satu Universitas lumayan terkenal di Milan.\n" +
                        "\n" +
                        "           Awalnya bapak Rahman tidak setuju,tapi karena di yakinkan oleh Rahman akhirnya ia setuju.Menimba ilmu di Milan ,Rahman menpunyai dua sahabat yang belakangan delapan belas bulan ini sangat dekat dengan Rahman.Namanya adalah Moza danBeto yang ke duanya adalah orang Indonesia.Dari awal bertemu dengan Rahman .Moza sudah menyimpan perasaan yang lebih terhadap Rahamn.Moza sempat mengutarakan perasaanya ,tapi tak parnah di jawab oleh Rahman.      \n" +
                        "\n" +
                        "          Sudah delapan belas bulan Rahman tidak bertemu dengan Aji.Entah kemana  sahabatnya itu.Sampai suatu hari Aji menemui Rahaman.Dan mengajak Rahman berkeliling studio foto tempat Aji berkerja.Aji mengundang Rahman dan Moza untuk mendatangi sekaligus menemani Aji untuk  melamar calon istrinya.\n" +
                        "\n" +
                        "       Mereka makan malam di suatu restoran yang ternama.Sebelum calon istri Aji datang, Aji memberikan surat yang dititipkan Salsabilla padanya.Moza  sangat kaget. Dan tunanagan Aji adalah orang  yang selama ini yang di cari Rahman di Milan .Tapi orang itu tidak peduli pada Rahman . Rahman sangat kecewa dan memutuskan pulang ke tanah air tarcinta yaitu  Indonesia.",
                "https://maskacung.com/"
        );

        tambahBuku(buku1, db);
        idBuku++;

        try {
            tempDate = sdFormat.parse("");
        } catch (ParseException er){
            er.printStackTrace();
        }

        Buku buku2 = new Buku(
                idBuku,
                "LASKAR PELANGI",
                tempDate,
                storeImageFile(R.drawable.buku2),
                "2005",
                "Bentang",
                "Andrea Hirata",
                "\n" +
                        "Cerita terjadi di desa Gantung, Kabupaten Gantung, Belitung Timur. Dimulai ketika sekolah Muhammadiyah terancam akan dibubarkan oleh Depdikbud Sumsel jikalau tidak mencapai siswa baru sejumlah 10 anak. Ketika itu baru 9 anak yang menghadiri upacara pembukaan, akan tetapi tepat ketika Pak Harfan, sang kepala sekolah, hendak berpidato menutup sekolah, Harun dan ibunya datang untuk mendaftarkan diri di sekolah kecil itu.\n" +
                        "\n" +
                        "Mulai dari sanalah dimulai cerita mereka. Mulai dari penempatan tempat duduk, pertemuan mereka dengan Pak Harfan, perkenalan mereka yang luar biasa di mana A Kiong yang malah cengar-cengir ketika ditanyakan namanya oleh guru mereka, Bu Mus. Kejadian bodoh yang dilakukan oleh Borek, pemilihan ketua kelas yang diprotes keras oleh Kucai, kejadian ditemukannya bakat luar biasa Mahar, pengalaman cinta pertama Ikal, sampai pertaruhan nyawa Lintang yang mengayuh sepeda 80 km pulang pergi dari rumahnya ke sekolah!\n" +
                        "\n" +
                        " \n" +
                        "  \n" +
                        "Mereka, Laskar Pelangi – nama yang diberikan Bu Muslimah akan kesenangan mereka terhadap pelangi – pun sempat mengharumkan nama sekolah dengan berbagai cara. Misalnya pembalasan dendam Mahar yang selalu dipojokkan kawan-kawannya karena kesenangannya pada okultisme yang membuahkan kemenangan manis pada karnaval 17 Agustus, dan kejeniusan luar biasa Lintang yang menantang dan mengalahkan Drs. Zulfikar, guru sekolah kaya PN yang berijazah dan terkenal, dan memenangkan lomba cerdas cermat. Laskar Pelangi mengarungi hari-hari menyenangkan, tertawa dan menangis bersama. Kisah sepuluh kawanan ini berakhir dengan kematian ayah Lintang yang memaksa Einstein cilik itu putus sekolah dengan sangat mengharukan, dan dilanjutkan dengan kejadian 12 tahun kemudian di mana Ikal yang berjuang di luar pulau Belitong kembali ke kampungnya.\n" +
                        "\n" +
                        " \n" +
                        "\n" +
                        "Kesulitan terus menerus membayangi sekolah kampung itu. Sekolah yang dibangun atas jiwa ikhlas dan kepeloporan dua orang guru, seorang kepala sekolah yang sudah tua, Bapak Harfan Efendy Noor dan ibu guru muda, Ibu Muslimah Hafsari, yang juga sangat miskin, berusaha mempertahankan semangat besar pendidikan dengan terseok-seok. Sekolah yang nyaris dibubarkan oleh pengawas sekolah Depdikbud Sumsel karena kekurangan murid itu, terselamatkan berkat seorang anak idiot yang sepanjang masa bersekolah tak pernah mendapatkan rapor.\n" +
                        "\n" +
                        "Sekolah yang dihidupi lewat uluran tangan para donatur di komunitas marjinal itu begitu miskin. Gedung sekolah bobrok, ruang kelas beralas tanah, beratap bolong-bolong, berbangku seadanya, jika malam dipakai untuk menyimpan ternak, bahkan kapur tulis sekalipun terasa mahal bagi sekolah yang hanya mampu menggaji guru dan kepala sekolahnya dengan sekian kilo beras, sehingga para guru itu terpaksa menafkahi keluarganya dengan cara lain. Sang kepala sekolah mencangkul sebidang kebun dan sang ibu guru menerima jahitan.\n" +
                        "\n" +
                        "Dari waktu ke waktu mereka berdua bahu membahu membesarkan hati kesebelas anak-anak tadi agar percaya diri, berani berkompetisi, agar menghargai dan menempatkan pendidikan sebagai hal yang sangat penting dalam hidup ini. Mereka mengajari kesebelas muridnya agar tegar, tekun, tak mudah menyerah, dan gagah berani menghadapi kesulitan sebesar apapun. Kedua guru itu juga merupakan guru yang ulung sehingga menghasilkan seorang murid yang sangat pintar dan mereka mampu mengasah bakat beberapa murid lainnya. Pak Harfan dan Bu Mus juga mengajarkan cinta sesama dan mereka amat menyayangi kesebelas muridnya. Kedua guru miskin itu memberi julukan kesebelas murid itu sebagai para Laskar Pelangi. \n" +
                        "\n" +
                        "Keajaiban terjadi ketika sekolah Muhamaddiyah, dipimpin oleh salah satu laskar pelangi mampu menjuarai karnaval mengalahkan sekolah PN dan keajaiban mencapai puncaknya ketika tiga orang anak anggota laskar pelangi (Ikal, Lintang, dan Sahara) berhasil menjuarai lomba cerdas tangkas mengalahkan sekolah-sekolah PN dan sekolah-sekolah negeri. Suatu prestasi yang puluhan tahun selalu digondol sekolah-sekolah PN.\n" +
                        "\n" +
                        "Tak ayal, kejadian yang paling menyedihkan melanda sekolah Muhamaddiyah ketika Lintang, siswa paling jenius anggota laskar pelangi itu harus berhenti sekolah padahal cuma tinggal satu triwulan menyelesaikan SMP. Ia harus berhenti karena ia anak laki-laki tertua yang harus menghidupi keluarga, sebab ketika itu ayahnya meninggal dunia.\n" +
                        "  \n" +
                        "Meskipun awal tahun 90-an sekolah Muhamaddiyah itu akhirnya ditutup karena sama sekali sudah tidak bisa membiayai diri sendiri, tapi semangat, integritas, keluruhan budi, dan ketekunan yang diajarkan Pak Harfan dan Bu Muslimah tetap hidup dalam hati para laskar pelangi.\n" +
                        "\n" +
                        "Akhirnya kedua guru itu bisa berbangga karena diantara sebelas orang anggota laskar pelangi sekarang ada yang menjadi wakil rakyat, ada yang menjadi research and development manager di salah satu perusahaan multi nasional paling penting di Negeri ini, ada yang mendapatkan bea siswa international kemudian melakukan research di University de Paris, Sorbonne dan lulus S2 dengan predikat with distinction dari sebuah universitas terkemuka di Inggris. Semua itu, buah dari pendidikan akhlak dan kecintaan intelektual yang ditanamkan oleh Bu Mus dan Pak Harfan.",
                "http://unik-mahasiswa.blogspot.com/2018/04/sinopsis-dan-resensi-novel-laskar.html"
        );

        tambahBuku(buku2, db);
        idBuku++;

        try {
            tempDate = sdFormat.parse("");
        } catch (ParseException er){
            er.printStackTrace();
        }

        Buku buku3 = new Buku(
                idBuku,
                "BUMI MANUSIA",
                tempDate,
                storeImageFile(R.drawable.buku3),
                "2002",
                "Hasta Mitra",
                "Pramoedya Ananta Toer",
                "Bumi manusia, salah satu mahakarya terbesar dalam bidang sastra Indonesia, yang dibuat oleh sastrawan yang memang mengabdikan hidupnya untuk sebuah proyek keabadian—Pramoedya Ananta Toer. Satu-satunya sastrawan Indonesia yang pernah enam kali di nominasikan sebagai peraih nobel perdamaian pada masanya.\n" +
                        "\n" +
                        "Karyanya novel Bumi Manusia merupakan buku pertama dalam tetralogi Pramoedya, yang terdiri dari, berturut-turut Bumi Manusia, Anak Semua Bangsa, Jejak Langkah, dan Rumah Kaca. Pramoedya menulisnya ketika di tahan di Pulau Buru, sebagai tahanan politik Orde baru. Meski mendapat sambutan yang luar biasa dari dalam dan luar negeri, pada tahun pertama penerbitannya—bukunya harus mendapati tantangan yang bisa bilang suatu kemunduran, karena dilakukannya pelarangan pada karyanya itu—dikatakan bahwa bukunya mengandung ajaran Marxisme dan Leninisme—sebuah ajaran yang dilarang pada masa pemerintahan Orde Baru.[1]\n" +
                        "\n" +
                        "Kisah Bumi Manusia bisa ditempatkan sebagai sebuah karya yang merupakan salah satu warisan sejarah terbaik Bangsa Indonesia. Sebuah buku yang mengisahkan periode kehidupan di Indonesia dari tahun 1898-1918, dimana periode tersebut merupakan tumbuhnya benih-benih pemikiran Politik Etis dan masa Kebangkitan Nasional. Nyaris tiada sastrawan yang berhasil menceritakan kehidupan pada masa itu sebaik Pramoedya dalam tetraloginya, terutama dalam kisah Bumi Manusia.\n" +
                        "\n" +
                        "Kisah Bumi Manusia sendiri mendapatkan banyak sekali apresiasi setelah pertama kali terbit pada tahun 1980. Hingga tahun 2005, kisah Bumi Manusia telah diterjemahkan ke 33 bahasa di dunia dan sekarang sudah sekitar 40 bahasa,[2] selain itu juga—apresiasinya dilakukan kedalam berbagai pertunjukan teater, pada tahun 2006 di gelar di 12 kota besar di Indonesia secara serentak. Dan juga, tidak kalah menghebohkan, bahwasannya kisah Bumi Manusia ini akan difilmkan oleh Falcon Picture dengan sutradara Hanum Bramantyo dan tokoh utamnya—Minke, diperankan oleh Iqbal Ramadhan.\n" +
                        "\n" +
                        "Rencana difilmkannya kisah Bumi Manusia dilakukan sejak 2004, namun terealisasi pada tahun ini—2019. Hal ini juga menarik antusiasme masyarakat, yang mencintai sastra maupun baru mencintai, terlebih lagi tokoh utamanya yang diperankan oleh Iqbal Ramadhan, membikin antusiasme—terutama kaum milenial untuk bisa menonton film ini.\n" +
                        "\n" +
                        "Untuk itu, penting juga rasanya—agar kita semua tahu bagaiamana duduk perkaranya, hingga benar-benar kita bisa memetik pelajaran berharga dari kisah Bumi Manusia ini, kiranya itulah latar belakang penulis mencoba memberikan ulasan karya ini. Karena seperti kata Susilo Toer, adik Pramoedya yang masih hidup—kisah Bumi Manusia itu bagi orang yang membacanya secara mendalam sangatlah kompleks, di dalammnya terdapat sebuah pengajaran yang luar biasa mengenai perjuangan Pribumi melawan penjajah; pribumi menyingkirkan budaya Jawa yang kolot; perjuangan perempuan yang di deskriminasi oleh penjajah, maupun bangsa sendiri; perjuangan mendapat pendidikan; hingga pengenalan budaya bangsa yang sangat bermakna. Bukan semata-mata kisah cinta kedua tokoh utama—yaitu Minke dan Annalies, yang akan diceritakan oleh Hanum Bragmantyo, selaku sutradara film.\n" +
                        "\n" +
                        "Bumi Manusia merupakan sebuah buku bergenre fiksi yang berlatar belakang kehidupan pada masa penjajahan Belanda. Di dalam buku ini, diceritakan hiduplah seorang pemuda Pribumi bernama Minke, yang mendapati dirinya bersekolah di Hogere Burgerschool (HBS), sebuah sekolah yang sekarang setingkat dengan SMA, dan diperuntukan untuk orang Belanda, Eropa dan Elite Pribumi. Minke sendiri merupakan anak Bupati kota B (disebutkan dalam cerita)—dirinya disekolahkan agar kemudian bisa menjadi Bupati seperti ayahnya, meski Minke bersikeras menolaknya.\n" +
                        "\n" +
                        "Sebagai Pribumi, Minke merupakan anak yang cerdas di HBS, kemampuannya dalam menulis telah membawanya menjadi seorang yang cukup dikenal di Jawa, karena tulisannya banyak diterbitkan di koran berbahasa Belanda, dengan nama samaran Max Tollenar.\n" +
                        "\n" +
                        "Namun, pendidikan yang diterima Minke di HBS, menjadikannya pribadi yang sangat mengagungkan Eropa, terutama karena pengajaran gurunya Juffrouw Magda Peters. Minke sangat menyanjung Eropa dan dikisahkan tidak lagi mengindahkan budaya Jawa. Meski pada akhirnya, Minke sendiri mendapati bahwa Eropa yang Ia sanjung tidak lebih sebagai bangsa pendindas terhadap bangsa lain—hal itu diceritakan secara dramatis oleh Pramoedya, yaitu bagaimana awalnya Minke menyanjung Eropa hingga akhirnya Ia dibuat benci untuk melakukan itu.\n" +
                        "\n" +
                        "Seperti diceritakan di awal, kisah Bumi Manusia ini sangatlah kompleks—namun penekanan yang penulis dapat dari kisah ini adalah mengenai kemanusiaan, Pramoedya dengan lihai menjelaskan konsep itu dalam kisah yang sangat indah.\n" +
                        "\n" +
                        "Ceritanya berawal ketika Minke yang mendapati dirinya ditantang oleh seorang teman—bernama Robert Suurhof, untuk pergi ke Wonokromo, mengunjungi seorang wanita cantik—bernama Annalies Melemma. Suurhof akhirnya menjadi musuh Minke, karena mencintai wanita yang sama, yaitu Annalies Melemma, celakanya Annalies juga mencintai Minke daripada Suurhof. Annalies tinggal disebuah rumah besar yang indah bersama Nyai Ontosoroh, yang merupakan seorang Nyai,[3] dan kakanya Robert Mellema.\n" +
                        "\n" +
                        "Selain Minke dan Annalies, Nyai Ontosoroh juga mendapat penekanan dalam kisah Bumi Manusia, bahkan dalam beberapa pertunjukan teater, justru Nyai Ontosoroh lah yang menjadi pemeran utamanya. Diceritakan dirinya di jual oleh ayahnya sendiri kepada orang Belanda, agar ayahnya naik jabatan. Secara menyedihkan, Nyai Ontosoroh tanpa pernikahan harus rela mendapati dirinya hidup bersama Tuan Mellema, yang bahkan tidak pernah Ia kenal sebelumnya.\n" +
                        "\n" +
                        "Karena dendam Nyai Ontosoroh pada orang tuanya, Nyai bertekad untuk mengangkat harkat martabatnya sendiri dengan pengetahuan. Nyai belajar banyak dari Tuan Mellema—hidup seperti bangsa Eropa, membaca buku Eropa, belajar baca tulis, dan belajar mengelola perusahaan. Tuan Mellema awalnya baik dan sangat mencintai Nyai Ontosoroh, meski tidak pernah menikahinya secara resmi secara hukum dan agama. Namun bencana datang ketika anak sah Tuan Mellema datang dari Belanda untuk bekerja di Indonesia dan menuntut Tuan Mellema, semuanya menjadi kacau, Tuan Mellema pergi meninggalkan Nyai Ontosoroh.\n" +
                        "\n" +
                        "Meski begitu, Nyai Ontosoroh sudah banyak belajar, bersama Annalies kedua perempuan itu membangun sebuah perusahaan yang sangat besar. Bisa dikatakan meski hanya seorang Nyai, Ontosoroh membikin dirinya dihormati karena kekayaannya yang melimpah, hasil jerih payahnya sendiri, menjadikannya wanita yang mandiri. Sementara Robert Mellema sudara Annalies Mellema, lebih mengikuti ayahnya dan membenci Nyai Ontosoroh sebagai Ibunya.\n" +
                        "\n" +
                        "Minke yang datang ke kehidupan Nyai Ontosoroh dan Annalies disambut baik oleh mereka berdua. Banyak yang membenci hal itu, termasuk orang tua Minke, karena Ontosoroh adalah seorang Nyai—begitupun Robert Mellema dan tentunya Suurhof, keduanya secara terang-terangan menyerang Minke dan mengatakannya sebagai orang yang ingin mendapati kekayaan Nyai Ontosoroh.\n" +
                        "\n" +
                        "Meski mendapati diri dalam tantangan yang panjang, Minke tetap saja berusaha untuk mendapatkan Annalies, menurutnya hal itu sebanding—karena Annales adalah wanita cantik dan berkepribadian baik, hal itu terbukti dari sikapnya yang bisa mengurusi perusahaan bersama Ibunya, Nyai Ontosoroh.\n" +
                        "\n" +
                        "Setelah perjuangan yang sangat berat, Minke dan Annalies akhirnya menikah, keduanya sangat bahagia, karier Minke pun melejit dengan baik. Minke berhasil lulus dari HBS dengan peringkat yang sangat memuaskan, padahal dia pernah dikeluarkan dari sekolah, karena tuduhan-tuduhann yang mengarah padanya telah melakukan hal buruk dengan seorang Nyai. Semuanya Minke hadapi, dan akhirnya dia bisa berhasil.\n" +
                        "\n" +
                        "Setelah kegembiraan Minke dapatkan, bencana datang menghampirinya, Minke jatuh sejatuh-jatuhnya. Dan yang menjatuhkannya adalah hukum Belanda—hukum orang Eropa, sebuah negara yang Ia sanjung-sanjung. Setelah kematian Tuan Mellema yang misterius, anak Sah Tuan Mellema dari Belanda yang sedari awal telah menghancurkan rumah tangga Tuan Mellema dengan Nyai Ontosoroh menuntut harta Tuan Mellema yang dikelola Nyai Ontosoroh. Annalies sama-sama menjadi korban, karena merupakan anak sah Tuan Mellema,[4] Ia harus dipulangkan ke Eropa dan meninggalkan Minke bersama Nyai Ontosoroh—Nyai tidak dianggap karena tidak pernah menikah secara sah dengan Tuan Mellema dan harus merelakan semua perusahaan yang telah Ia rintis dengan Annalies.\n" +
                        "\n" +
                        "Meski Minke dan Nyai Ontosoroh telah berusaha keras untuk mempertahankan perusahaan dan Annalies yang harus dibawa ke Belanda, tetap saja hukum tidak pernah memihak pada Pribumi. Annalies pergi, Minke dan Nyai harus pasrah dan menerima semuanya. Di akhir buku, Minke berkata pada Nyai Ontosoroh, “Kita kalah Ma,” bisik Minke, dan dengan bijak Nyai Ontosoroh menjawab, “Kita telah melawan, Nak, Nyo, sebaik-baiknya, sehormat-hormatnya,”.\n" +
                        "\n" +
                        "Buku Bumi Manusia ini secara penulisan ditulis dengan sangat apik. Ceritanya runtut dan penuh makna. Setiap bab diceritan dengan pembabakan yang jelas, dan terkadang terjadi perubahan pencerita atau orang pertama, misalnya dari Minke, menuju Annalies, kemudian Nyai Ontorsoroh—tetapi semuanya mudah dipahami dan justru menambah pemahaman terhadap bagaimana pembangunan karakter-karakter dalam cerita kisah Bumi Manusia. Seperti ketika Nyai Ontosoroh sebagai orang pertama, menjelaskan bagaimana bisa dirinya menikah dengan seorang Eropa, dari hasil dirinya dihinakan oleh adat Jawa—hidupnya hanya dikehendaki nurut dengan Bapak, apapun kehendak yang dibuat harus dituruti.\n" +
                        "\n" +
                        "Dari segi nilai yang bisa di dapat, buku ini luar biasa memiliki hal itu. Mungkin dari semua keunggulannya, amanat nilai-nilai kemanusiaan yang diberikan buku ini adalah yang paling diunggulkan. Berikut penulis kutip kalimat-kalimat yang menurut penulis sangatlah indah dan bermakna, khususnya bagi penulis sendiri.",
                "http://pusdimafis.blogspot.com/2019/03/resensi-buku-bumi-manusia-karya.html"
        );

        tambahBuku(buku3, db);
        idBuku++;

        try {
            tempDate = sdFormat.parse("");
        } catch (ParseException er){
            er.printStackTrace();
        }

       Buku buku4 = new Buku(
                idBuku,
                "SANG PEMIMPI",
                tempDate,
                storeImageFile(R.drawable.buku4),
                "2008",
                "PT Bentang Pustaka",
                " Andrea Hirata",
                "Setelah 40 tahun bumi pertiwi merdeka, akhirnya Belitong Timur, pulau timah yang kaya raya itu, memiliki sebuah SMA Negeri, yaitu SMA Negeri Bukan Main. Artinya tidak perlu lagi menempuh 120 kilometer untuk mengenyam pendidikan di bangku SMA. Namun tetap tidak mudah, karena sang kepala sekolah, Drs. Julian Ichsan Balia, yang juga seorang guru kesusastraan, sangat disiplin dan konsisten dalam menentukan siapa anak didiknya, NEM minimal 42, tidak bisa ditawar-tawar. Bahkan Mustar M. Djai’din, B.A, seorang guru biologi yang juga merupakan salah satu perintis berdirinya SMA Negeri Bukan Main, tidak berhasil menggoyahkan kokohnya peraturan Pak Balia. Meski beropini apapun anak laki-lakinya yang memiliki NEM 41,75 tetap gagal menjadi siswa di sekolah yang telah diusahakannya itu.\n" +
                        "\n" +
                        "\n" +
                        "REPORT THIS AD\n" +
                        "\n" +
                        "Ikal, Arai, dan Jimbron, yang merupakan tokoh protagonis dalam novel ini, diterima bersekolah di SMA Negeri Bukan Main. Mereka salah satu anak dari keluarga kurang beruntung di kampung terpencil di Belitong.  Ikal sedikit lebih beruntung dari Arai dan Jimbron. Karena walau ia hanyalah anak seorang pekerja PN Timah Belitong yang terancam terseret gelombang PHK, setidaknya ia memiliki keluarga yang lengkap dan penuh cinta kasih. Ia sangat mengagumi sosok ayahnya, yang ia sebut juara satu seluruh dunia.\n" +
                        "\n" +
                        "Sedangkan Arai dan Jimbron memiliki kisah yang dapat dikatakan serupa. Arai merupakan simpai keramat, yakni orang terakhir yang tersisa dari suatu klan. Saat ia kelas satu SD, Ibunya meninggal ketika melahirkan, begitu pula adiknya yang baru lahir. Belum berakhir masa dukanya, saat ia naik kelas tiga SD, ayahnya dipanggil oleh Yang Maha Kuasa. Arai yang ternyata adalah sepupu jauh Ikal, kemudian diadopsi oleh Pak Seman Said Harun, ayah Ikal.\n" +
                        "\n" +
                        "Jimbron yang kini gagap sebenarnya memiliki kisah amat pilu dibalik kegagapannya. Jimbron memiliki dua adik kembar perempuan. Ibunya wafat ketika Jimbron kelas empat SD. Sementara ayah yang ia jadikan orientasi hidupnya, terkena serangan jantung saat membonceng Jimbron dengan sepeda. Saat itu belum sampai 40 hari ibunya wafat. Jimbron sekuat tenaga pontang-panting membonceng ayahnya menuju Puskesmas. Setelah beberapa menit di Puskesmas, ayah Jimbron meninggal. Sejak saat itu Jimbron gagap. Kejadian memilukan itu juga berakibat munculnya ketertarikan Jimbron pada kuda yang mencapai tingkat obsesi komplusif. Kedua adik kembarnya diasuh bibinya di Pangkal Pinang, Pulau Bangka, sedangkan Jimbron diasuh oleh Pendeta Geovanny, sahabat keluarganya.\n" +
                        "\n" +
                        "Ikal, Arai, dan Jimbron menyewa kamar kontrakan di Magai, karena jarak dari sekolah ke kampungnya terlalu jauh, yaitu 30 kilometer. Demi membiayai kehidupan dan membantu keluarga, mereka bekera menjadi kuli ngambat. Pekerjaan teramat berat dan kasar ini mengharuskan ketiganya bangun pukul 2 pagi, mengangkut ikan-ikan yang panjangnya rata-rata mencapai dua meter. Biasanya pekerjaan ini selesai pada pukul enam, sehingga mereka akan tergesa-gesa menggunakan sisa waktu sebelum jam tujuh.\n" +
                        "\n" +
                        "Namun, walau bekerja sebegitu berat sambil sekolah, mereka tetap tidak melupakan status pelajar yang melekat dalam diri mereka. Buktinya, saat pembagian rapot, Ikal dan Arai berada di garda depan (peringkat sepuluh besar), Ikal di peringkat ketiga dan Arai di peringkat kelima. Sedangkan Jimbron, yang tumbuh invalid (kakinya panjang sebelah), namun memiliki semangat dan ketenangan yang luar biasa, berhasil mempersembahkan kursi nomor 78 untuk Pendeta Geo. Mereka punya mimpi yang hebat: berkelana menjelajahi Eropa sampai ke Afrika. Sekolah ke Prancis. Menginjakkan kaki di altar suci almamater Sorbonne.\n" +
                        "\n" +
                        "\n" +
                        "REPORT THIS AD\n" +
                        "\n" +
                        "Ikal, Arai, dan Jimbron, walau memberi inspirasi, tetap saja adalah remaja. Mereka tidak lepas dari jeratan perasaan yang sulit diterjemahkan dengan berbagai pemahaman dan kata-kata, yang disebut cinta. Ikal tetap setia pada cinta pertama yang entah dimana kini, A Ling, anak pemilik Toko Sinar Harapan. Arai pantang menyerah menjaga dan membuktikan cintanya pada sosok wanita yang sayangnya sangat tidak peduli. Pengorbanannya yang gigih, entah menguap kemana bagi seorang Zakiah Nurmala binti Berahim. Dan Jambron, lebih dari keobsesian komplusifnya terhadap kuda, ia mencintai Laksmi, gadis malang yang seakan lupa bagaimana cara tersenyum sejak keluarganya terenggut dalam peristiwa kecelakaan kapal di semenanjung yang kini dinamakan semenanjung Ayah.\n" +
                        "\n" +
                        "Sebagai remaja, mereka terkadang lalai dan tergoda dengan gejolak perubahan menuju dewasa. Oleh karena itu, ketiganya kadang terseret masalah-masalah yang menimpa remaja pada umumnya. Namun dibalik setiap persoalan yang mereka ikut nimbrung atau bahkan yang mereka sebabkan, mereka mampu memetik dan menyimpulkan hikmah.\n" +
                        "\n" +
                        "Ikal yang kini menginjak usia delapan belas rupanya telah mulai memahami realitas kehidupan. Ia kehilangan semangatnya. Dulu ia optimis bermimpi hingga melampaui posibilities-line, tapi kini, membayangkan mimpinya yang sangat tinggi itu, ia tersenyum pahit, menertawakan diri sendiri. Ia jadi banyak merenung memikirkan nasibnya masa depan yang paling banter menjadi pelayan restoran mi rebus atau kernet mobil omprengan reyot.\n" +
                        "\n" +
                        "Walhasil, ia mempermalukan ayah yang ia cintai pada acara pembagian rapot di semester berikutnya. Ikal terhempas dari garda depan, merosot ke peringkat 75. Pak Mustar menerjangnya dengan kata-kata yang menyayat, ditambah kemarahan Arai yang membuat dadanya sesak. Puncaknya adalah ketabahan sang ayah yang pendiam, yang selalu menganggap hari pembagian rapot anaknya adalah momentum penting dalam hidupnya. Ia mengenakan setelan terbaiknya dan mengendarai sepeda sejauh 30 kilometer demi  menerima rapot anaknya. Ia tidak pernah berkata apapun, selain mengucap salam dan tersenyum bangga. Semua itu, ditambah penyesalan yang amat sangat, mampu membuatnya bangkit lagi.\n" +
                        "\n" +
                        "Di semester terakhirnya bersekolah di SMA Negeri Bukan Main, Ikal berhasil membersihkan nama baik ayahnya, mempersembahkan kursi nomor tiga. Arai melejit naik menempati kursi nomor dua, tepat di samping kirinya, pujaan hati Arai bertengger, Nurmala tetap di posisi pertama sejak kelas sepuluh.\n" +
                        "\n" +
                        "Berbekal tabungan hasil kerja sebagai kuli ngambat selama kurang lebih tiga tahun, ditambah masing-masing sebuah celengan penuh, pemberian dari Jimbron, Arai dan Ikal berangkat ke Jakarta. Mereka hanya memiliki dua petunjuk. Yang pertama adalah dari mualim kapten kapal Bintang Laut Selatan: tujulah Ciputat di Jakarta Selatan, tempat itu lumayan aman dibanding wilayah Jakarta lainnya. Yang kedua adalah wejangan kedua orangtuanya agar setiba di Jakarta mereka harus menemukan masjid terlebih dahulu. Namun, mereka malah terdampar di Bogor dengan pengetahuan sangat minim tentang kota itu.\n" +
                        "\n" +
                        "\n" +
                        "REPORT THIS AD\n" +
                        "\n" +
                        "Keberuntungan datang berbondong-bondong kepada dua petualang pencari ilmu ini. Mereka berhasil mencapai kompleks IPB, menemukan masjid, dan keesokan harinya menyewa kamar kontrakan di kawasan tersebut. Lebih dari itu, mereka berhasil memperoleh pekerjaan menjadi salesman. Namun, jiwa pekerja kasar yang melekat pada diri mereka bahkan selama tiga generasi sebelumnya tidak mampu ditransformasi seketika menjadi pedagang dalam masa percobaan satu bulan. Mereka kembali menganggur setelah diputuskan gagal menjadi salesman. Beruntung, salah satu sahabat mereka yang mempunyai usaha fotokopi merekrut keduanya.\n" +
                        "\n" +
                        "Tawaran menjadi pegawai pos ternyata cukup menggiurkan. Namun prosesnya lumayan berat. Mereka harus menjalani beberapa test dan pelatihan fisik berbulan-bulan. Arai tersingkir pada test paru-paru, sedangkan Ikal melenggang maju hingga sukses menjadi pegawai pos bagian penyortiran surat. Tanpa sepengetahuan Ikal dan tanpa memberitahu alamat jelas, Arai bersama seorang temannya pergi ke Kalimantan untuk bekerja.\n" +
                        "\n" +
                        "Ikal sangat lega karena akhirnya dapat mengenyam pendidikan lagi, tidak tanggung-tanggung, Fakultas Ekonomi di Universitas Indonesia. Di sumur ilmu yang kondang hingga berpuluh-puluh tahun berikutnya itu, Ikal bertemu Zakiah Nurmala. Sayang, Arai sedang tidak bersamanya.\n" +
                        "\n" +
                        "Ikal baru saja lulus kuliah saat membaca pengumuman beasiswa strata dua yang diberikan Uni Eropa kepada sarjana-sarjana Indonesia. Ikal tidak sedetikpun melewatkan kesempatan berharga ini. Ia belajar jungkir balik demi mewujudkan mimpinya. Ia akhirnya berhasil melalui berbagai test panjang dan melelahkan, juga wawancara akhir. Saat itu, ia bertemu Arai kembali setelah berbulan-bulan berpisah. Arai juga mengambil kesempatan ini. Keduanya lalu memutuskan penantian hasil test akan mereka habiskan di kampung halaman,  Belitong.\n" +
                        "\n" +
                        "Arai dan Ikal menemui sahabat lamanya, yang turut menyumbang dalam kesuksesan mereka hingga mencapai hari itu. Jimbron. Ia sukses merebut hati Laksmi dan membuat gadis itu tersenyum sepanjang waktu. Mereka kini mempunyai seorang anak berusia lima tahun. Arai dan Ikal lalu berkeliling kampung.\n" +
                        "\n" +
                        "Dua amplop surat berisi keputusan hasil tes tiba di kediaman Bapak Seman Said Harun. Usai sholat Maghrib, Ikal dan kedua orangtuanya, arai ditemani foto alm. kedua orangtuanya, membuka suratnya masing-masing. Keduanya lulus tes dan berhak menerima beasiswa Uni Eropa, di Universitas yang sama, Universite de Paris, Sorbonne, Prancis.",
                "https://dilaflaurndhia.wordpress.com/2016/08/11/resensi-novel-sang-pemimpi-karya-andrea-hirata/"
        );

        tambahBuku(buku4, db);
        idBuku++;

        try {
            tempDate = sdFormat.parse("");
        } catch (ParseException er){
            er.printStackTrace();
        }

        Buku buku5 = new Buku(
                idBuku,
                "JALAN TAK ADA UJUNG",
                tempDate,
                storeImageFile(R.drawable.buku5),
                "1952",
                "Yayasan Obor Indonesia",
                " Mochtar Lubis",
                "Novel ini menceritakan seorang guru yang bernama Isa yang mengajar di sebuah sekolah di Tanah Abang. Ia hidup di kala revolusi di saat para pemuda sedang gencar-gencarnya melakukan perlawanan terhadap tentara Belanda yang ingin menguasai kembali Indonesia.\n" +
                        "Dalam Novel ini Guru Isa di gambarkan sebagai seseorang yang cinta damai, dan tidak menyukai kekerasan. Dengan terpaksa karena takut ia di  tuduh sebagai mata-mata musuh. Ia mengikuti sebuah organisasi rahasia di kampungnya, dan ia terpilih menjadi kurir atau pengantar senjata dan surat-surat di dalam kota Jakarta.\n" +
                        "Ia mempunyai seorang Istri bernama Fatimah. Selama pernikahannya ia tidak di karuniai seorang anak, dikarenakan Guru Isa yang mengalamai Impotensi. Akhirnya atas permintaan istrinya, mereka mengangkat seorang anak bernama Salim. Kehidupan mereka tidak sebahagia dulu setelah menikah. Isa tidak pernah melihat lagi sinar mata Fatimah seperti dahulu sebelum mereka menikah. Keadaan ekonominya juga buruk karena penghasilan Guru Isa sangat tidak menentu. Sehingga Fatimah hatus mengutang kemana-mana, sampai suatu saat keadaannya benar-benar terdesak, hingga akhirnya Guru Isa mencuri buku tulis yang ada di sekolah.\n" +
                        "Karena kesamaan hoby bermain biolanya. Guru Isa menjadi dekat dengan Hazil – seorang pemuda yang ia kenal lewat organisasi pemberontakan di kampungnya. Hazil adalah anak dari Mr. Kamaruddin, pensiunan Kepala Landraad.\n" +
                        "Bersama Hazil, dan seorang supir bernama Abdullah, mereka pergi menyelundupkan senjata ke Karawang menggunakan mobil Tuan Hamidi. Di Asam Reges, mereka bertemu dengan Rakhmat, dengan Ontong dan teman-temannya. Dari Ontong ia di ceritakan bahwa beberapa waktu yang lalu, mereka habis telah membunuh 2 orang perempuan Tionghoa yang dianggap sebagai mata-mata musuh. Guru Isa menjadi takut bercampur ngeri.\n" +
                        "Pada suatu hari Guru Isa menderita penyakit malaria. Ketika itu Hazil datang menjenguk. Selesainya ia membantu Fatimah menyalakan api tungku. Dan semenjak itu hubungan gelap terjadi antara Hazil dan Fatimah.\n" +
                        "Pernah ketika Guru Isa sedang tidur, ia menemukan sebuah pipa milik Hazil di bawah tempat tidur. Dari situlah ia mengetahui bahwa istrinya selingkuh, namun ia lebih memilih untuk diam.\n" +
                        "Dengan pengorbanan jiwa yang besar Guru Isa menyetujui rencana Hazil dan Rakhmat untuk melempar granat tangan ke sebuah bioskop Rex. Namun, seminggu kemudian ia membaca sebuah koran yang berisi bahwa salah seorang pelaku pelempar granat tangan tertangkap. Jelas berita itu membuat Guru Isa takut setengah mati. Ia belum mengetahui siapa yang tertangkap. Rakhmat atau Hazil?\n" +
                        "Dan beberapa hari setelahnya Guru Isa ditangkap oleh polisi. Di sana ia di interogasi. Dalam tahanan ia mengetahui bahwa Hazillah yang tertangkap. Hazil sangat menyesal dan hampir mati dalam ketakutannya.dan guru Isa tetap tegar dan berhasil melewati masa-msa ketakutan itu.\n" +
                        "Novel ini sangat pantas untuk di baca, dengan tema perjuangan seorang guru di masa revolusi. Ada beberapa kelebihan dalam novel ini terutama dalam setting yang sangat kuat. Dengan perincian situasi yang sangat mendetail. Selain itu penokohannya juga terlihat jelas. Hanya kekurangannya adalah pemilihan gaya bahasa yang sederhana. Mochtar Lubis menggunakan sudut pandang orang pertama dan sudut pandang orang ketiga dengan alur maju. Amanat dari novel ini adalah untuk tidak menjadi orang yang penakut, berjuanglah demi kebenaran asal harus berasaskan peri kemanusiaan.",
                "http://putriiilarasati.blogspot.com/2013/01/nama-putrilarasati-kelas-xi-a1-no.html"
        );
        tambahBuku(buku5, db);
    }
}
